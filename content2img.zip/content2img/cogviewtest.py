import time
import requests
import json

url= "https://pretrain.aminer.cn/api/v1/cogview"
testurl = "https://pretrain.aminer.cn/api/v1/status"

generatestr = input("请输入图片主题")
def wudaoapi(keyword):
    content ={
            "key":"dhm", #队列名
            "query": keyword,  #用户输入的内容
            "apikey": "",
            "apisecret": ""
             }
    response = requests.post(url,json = content)
    realcontent = json.loads(response.content)
    taskid = {"task_id":realcontent["result"]["task_id"]}
    print(taskid)
    flag= 0
    while True:
        response2 = requests.get(testurl, taskid)
        if json.loads(response2.content)["result"]["process_time"] != 0:
            print(json.loads(response2.content)["result"]["output"])
            break
        time.sleep(2)

wudaoapi(generatestr)
